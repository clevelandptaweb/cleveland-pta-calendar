export function showEvent(event) {

    const oldModal = document.querySelector('.event-modal-overlay')

    if (oldModal) {
        oldModal.remove()
    }

    const overlay = document.createElement('div')

    overlay.className = 'event-modal-overlay'

    overlay.innerHTML = `

        <div class="event-modal">

            <button class="event-close">
                ✕
            </button>

            <h2>${event.title}</h2>

            <p class="event-time">

                ${event.start
                    ? event.start.toLocaleString([], {
                        weekday:'long',
                        month:'long',
                        day:'numeric',
                        hour:'numeric',
                        minute:'2-digit'
                    })
                    : ''}

            </p>

            <div class="event-description">

                ${event.extendedProps.description || 'No description available.'}

            </div>

        </div>

    `

    document.body.appendChild(overlay)

    overlay.querySelector('.event-close')
        .addEventListener('click', () => overlay.remove())

    overlay.addEventListener('click', e => {

        if (e.target === overlay) {
            overlay.remove()
        }

    })

    document.addEventListener('keydown', function esc(e){

        if(e.key === 'Escape'){

            overlay.remove()

            document.removeEventListener('keydown', esc)

        }

    })

}