import { Calendar } from '@fullcalendar/core'
import dayGridPlugin from '@fullcalendar/daygrid'
import interactionPlugin from '@fullcalendar/interaction'
import googleCalendarPlugin from '@fullcalendar/google-calendar'

export function createCalendar(showEvent){

    const calendar = new Calendar(document.getElementById('calendar'),{

        plugins:[
            dayGridPlugin,
            interactionPlugin,
            googleCalendarPlugin
        ],

        headerToolbar:{
            left:'prev',
            center:'title',
            right:'today next'
        },

        buttonText:{
            today:'Today'
        },

        eventClick(info){

            info.jsEvent.preventDefault()

            showEvent(info.event)

        },

        initialView:'dayGridMonth',

        height:'auto',

        googleCalendarApiKey:'AIzaSyCp7hFTRipPKjm18NF3iipQJR8VKr8baPo',

        events:{
            googleCalendarId:'7883fe26beef225836a58410a416839cb57588d5c69053d5a233e9af3a67008f@group.calendar.google.com'
        }

    })

    calendar.render()

    return calendar

}