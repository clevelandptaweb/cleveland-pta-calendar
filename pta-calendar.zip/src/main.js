import './style.css'

import { getUpcomingEvents } from './google'
import { createCalendar } from './calendar'
import { showEvent } from './popup'

document.querySelector('#app').innerHTML = `
<div class="page">

  <header class="hero">
      <h1>Cleveland PTA & School Calendar</h1>
      <p>
          Stay up to date with PTA meetings, family events,
          fundraisers and important school dates.
      </p>
  </header>

  <section class="coming-up">

      <h2>Coming Up</h2>

      <div class="event-cards" id="upcomingEvents">

          <div class="event-card">
              <div class="event-icon">🩵</div>

              <div class="event-info">
                  <h3>Loading...</h3>
                  <p>Fetching upcoming events...</p>
              </div>
          </div>

      </div>

  </section>

  <section class="calendar-card">
      <div id="calendar"></div>
  </section>

</div>
`

createCalendar(showEvent)

loadUpcoming()

async function loadUpcoming() {

    const events = await getUpcomingEvents()

    const container = document.getElementById('upcomingEvents')

    container.innerHTML = ''

    events.forEach(event => {

        const start = new Date(event.start.dateTime || event.start.date)

        const date = start.toLocaleDateString('en-US', {
            month: 'long',
            day: 'numeric'
        })

        const time = event.start.dateTime
            ? start.toLocaleTimeString('en-US', {
                hour: 'numeric',
                minute: '2-digit'
            })
            : 'All Day'

        const style = getEventStyle(event.summary)

        const description = event.description
            ? event.description.substring(0, 120)
            : ''

        container.innerHTML += `
            <div class="event-card" style="border-top:6px solid ${style.color};">

                <div class="event-icon" style="background:${style.color};">
                    ${style.icon}
                </div>

                <div class="event-info">

                    <h3>${event.summary}</h3>

                    <p class="event-date">
                        <strong>${date}</strong><br>
                        ${time}
                    </p>

                    <p class="event-description">
                        ${description}
                    </p>

                </div>

            </div>
        `

    })

}

function getEventStyle(title) {

    title = title.toLowerCase()

    if (title.includes('book'))
        return { icon:'📚', color:'#005596' }

    if (title.includes('meeting'))
        return { icon:'🤝', color:'#E63946' }

    if (title.includes('spirit'))
        return { icon:'👕', color:'#4F88C6' }

    if (title.includes('welcome'))
        return { icon:'🎉', color:'#2A9D8F' }

    if (title.includes('dance'))
        return { icon:'💃', color:'#D63384' }

    if (title.includes('movie'))
        return { icon:'🍿', color:'#6F42C1' }

    if (title.includes('teacher'))
        return { icon:'🍎', color:'#F77F00' }

    if (title.includes('clothing'))
        return { icon:'👕', color:'#2AA9C9' }

    if (title.includes('candy'))
        return { icon:'🍬', color:'#FF5E7E' }

    if (title.includes('lunch'))
        return { icon:'🥪', color:'#43AA8B' }

    return { icon:'📅', color:'#005596' }

}