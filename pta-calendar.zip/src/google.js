const CALENDAR_ID =
  '7883fe26beef225836a58410a416839cb57588d5c69053d5a233e9af3a67008f@group.calendar.google.com'

const API_KEY =
  'AIzaSyCp7hFTRipPKjm18NF3iipQJR8VKr8baPo'

export async function getUpcomingEvents() {

    const now = new Date().toISOString()

    const url =
`https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(CALENDAR_ID)}/events?key=${API_KEY}&singleEvents=true&orderBy=startTime&timeMin=${now}&maxResults=5`

    const response = await fetch(url)

    const data = await response.json()

    console.log(data.items)

    return data.items
}